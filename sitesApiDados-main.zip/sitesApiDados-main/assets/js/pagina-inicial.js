const botao = document.querySelector(".btn");
botao.addEventListener("click", function () {
    window.location.href = "pagina-principal.html";
});